<?php
/**
 * Block: GM03 - Loader
 *
 * @used:
 *  - header.php
 *
 * @package Jafar
 */

?>

<div class="gm03">
	<img class='gm03__loading-icon' src='<?php bloginfo( 'stylesheet_directory' ); ?>/assets/img/Rolling-1s-100px.png' alt=''>
</div>
