const lazyLoadInstance = new LazyLoad({
  // Your custom settings go here
});